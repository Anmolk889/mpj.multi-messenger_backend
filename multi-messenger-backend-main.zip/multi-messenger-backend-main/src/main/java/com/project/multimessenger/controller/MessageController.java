package com.project.multimessenger.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.multimessenger.dto.MessageRequest;
import com.project.multimessenger.service.MessageService;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/message")   // 🔥 better API structure
public class MessageController {

    @Autowired
    private MessageService messageService;

    @GetMapping("/test")
    public String test() {
        return "Backend is working";
    }

    @PostMapping("/send")
    public ResponseEntity<?> sendMessage(@RequestBody MessageRequest request) {

        String result = messageService.processMessage(request);

        Map<String, String> response = new HashMap<>();
        response.put("message", result);

        return ResponseEntity.ok(response);
    }
}